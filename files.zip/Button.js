import Link from "next/link";

const base =
  "inline-flex items-center justify-center rounded-full px-6 py-3 text-base font-semibold transition-colors duration-200 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cobalt";

const variants = {
  primary: "bg-cobalt text-white hover:bg-cobalt-dark",
  secondary: "border border-ink/20 text-ink hover:border-ink hover:bg-white",
};

export default function Button({ href, variant = "primary", className = "", children, ...props }) {
  const classes = `${base} ${variants[variant]} ${className}`;
  if (href) {
    return (
      <Link href={href} className={classes} {...props}>
        {children}
      </Link>
    );
  }
  return (
    <button className={classes} {...props}>
      {children}
    </button>
  );
}
