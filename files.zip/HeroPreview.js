// Decorative mock of a website "assembling" itself. Pure CSS, no images.
const d = (ms) => ({ "--d": `${ms}ms` });

export default function HeroPreview() {
  return (
    <div className="relative mx-auto w-full max-w-xl" aria-hidden="true">
      <div
        className="assemble overflow-hidden rounded-2xl border border-ink/10 bg-white shadow-[0_30px_60px_-20px_rgba(35,64,224,0.35)]"
        style={d(100)}
      >
        <div className="flex items-center gap-2 border-b border-ink/10 bg-mist px-4 py-3">
          <span className="h-2.5 w-2.5 rounded-full bg-ink/20" />
          <span className="h-2.5 w-2.5 rounded-full bg-ink/20" />
          <span className="h-2.5 w-2.5 rounded-full bg-ink/20" />
          <span className="ml-3 rounded-full bg-white px-3 py-1 text-xs text-ink/50">yourbusiness.com</span>
        </div>

        <div className="space-y-4 p-5 sm:p-6">
          <div className="assemble flex items-center justify-between" style={d(300)}>
            <span className="h-3 w-20 rounded bg-ink" />
            <span className="flex gap-3">
              <i className="h-2 w-8 rounded bg-ink/20" />
              <i className="h-2 w-8 rounded bg-ink/20" />
              <i className="h-2 w-8 rounded bg-ink/20" />
            </span>
          </div>

          <div className="assemble grid grid-cols-5 gap-4" style={d(500)}>
            <div className="col-span-3 space-y-2.5 pt-2">
              <span className="block h-4 w-full rounded bg-ink" />
              <span className="block h-4 w-4/5 rounded bg-ink" />
              <span className="block h-2 w-full rounded bg-ink/20" />
              <span className="block h-2 w-3/4 rounded bg-ink/20" />
              <span className="mt-3 block h-7 w-24 rounded-full bg-cobalt" />
            </div>
            <div className="col-span-2 rounded-xl bg-sky" />
          </div>

          <div className="grid grid-cols-3 gap-3">
            {[700, 850, 1000].map((ms, i) => (
              <div key={ms} className="assemble space-y-2 rounded-xl bg-mist p-3" style={d(ms)}>
                <span className={`block h-8 rounded-lg ${i === 1 ? "bg-mint" : "bg-sky"}`} />
                <span className="block h-2 w-3/4 rounded bg-ink/30" />
                <span className="block h-2 w-1/2 rounded bg-ink/15" />
              </div>
            ))}
          </div>
        </div>
      </div>

      <div
        className="assemble absolute -left-2 top-1/3 hidden rounded-xl bg-mint px-4 py-3 text-sm font-semibold shadow-lg sm:block lg:-left-8"
        style={d(1200)}
      >
        Restaurant template
      </div>
      <div
        className="assemble absolute -bottom-4 right-2 hidden rounded-xl bg-ink px-4 py-3 text-sm font-semibold text-white shadow-lg sm:block lg:-right-4"
        style={d(1400)}
      >
        Live in days
      </div>
    </div>
  );
}
