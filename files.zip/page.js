import Navbar from "@/components/layout/Navbar";
import Hero from "@/components/sections/Hero";

export default function HomePage() {
  return (
    <>
      <Navbar />
      <main>
        <Hero />
        {/* Next sections go here: Services, Templates, Branding, Pricing, Contact */}
      </main>
    </>
  );
}
