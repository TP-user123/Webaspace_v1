// Central site config: edit content here, not inside components.
export const SITE = {
  name: "WebaSpace",
  tagline: "Websites, branding and ready-made templates for your business",
};

export const NAV_LINKS = [
  { label: "Services", href: "/#services" },
  { label: "Templates", href: "/#templates" },
  { label: "Branding", href: "/#branding" },
  { label: "Pricing", href: "/#pricing" },
  { label: "Contact", href: "/#contact" },
];

export const CTA = {
  primary: { label: "Browse templates", href: "/#templates" },
  secondary: { label: "Book a free consultation", href: "/#contact" },
};
