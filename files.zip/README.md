# WebaSpace

Next.js (App Router) + JavaScript + Tailwind CSS v4.

    npm install
    npm run dev     # http://localhost:3000

- Brand colors and fonts: `app/globals.css` (`@theme`)
- Nav links and CTA copy: `lib/site.js`
- New sections: add a file in `components/sections/` and drop it into `app/page.js`
