import { Bricolage_Grotesque, DM_Sans } from "next/font/google";
import "./globals.css";
import { SITE } from "@/lib/site";

const bricolage = Bricolage_Grotesque({ subsets: ["latin"], variable: "--font-bricolage" });
const dmSans = DM_Sans({ subsets: ["latin"], variable: "--font-dm" });

export const metadata = {
  title: `${SITE.name} | ${SITE.tagline}`,
  description:
    "WebaSpace designs and builds websites, creates brand identities, and sells ready-made website templates for your industry.",
};

export const viewport = { width: "device-width", initialScale: 1 };

export default function RootLayout({ children }) {
  return (
    <html lang="en" className={`${bricolage.variable} ${dmSans.variable}`}>
      <body className="antialiased">{children}</body>
    </html>
  );
}
