import Button from "@/components/ui/Button";
import HeroPreview from "@/components/sections/HeroPreview";
import { CTA } from "@/lib/site";

export default function Hero() {
  return (
    <section className="relative overflow-hidden bg-mist">
      <div className="mx-auto grid max-w-7xl items-center gap-14 px-5 py-16 sm:px-8 sm:py-20 lg:grid-cols-2 lg:gap-12 lg:py-28">
        <div>
          <h1 className="font-display text-4xl font-bold leading-[1.08] tracking-tight text-balance sm:text-5xl lg:text-6xl">
            A website for your business, built for you or ready to launch today.
          </h1>
          <p className="mt-6 max-w-lg text-lg leading-relaxed text-ink/75">
            WebaSpace designs, develops and brands custom websites. Want to start faster? Pick a
            ready-made template made for your industry and go live in days.
          </p>

          <div className="mt-9 flex flex-col gap-3 sm:flex-row">
            <Button href={CTA.primary.href}>{CTA.primary.label}</Button>
            <Button href={CTA.secondary.href} variant="secondary">{CTA.secondary.label}</Button>
          </div>

          <p className="mt-8 text-sm text-ink/60">
            Templates for restaurants, clinics, studios, shops and more.
          </p>
        </div>

        <HeroPreview />
      </div>
    </section>
  );
}
